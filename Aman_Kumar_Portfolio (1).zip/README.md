# Aman Kumar — Personal Portfolio

A responsive personal portfolio website built with HTML, CSS, and JavaScript.

## Sections
- Home — introduction and portfolio overview
- About — student profile and interests
- Skills — current learning toolkit
- Projects — project showcase
- Contact — email contact section

## Technologies
- HTML5
- CSS3
- JavaScript
- Google Fonts

## Run locally
1. Download or clone this repository.
2. Open `index.html` in your browser.

## Customize before publishing
- Replace `your.email@example.com` in `index.html` with your email address.
- Add your actual projects and project links.
- Update skills to reflect your current experience.
- Add your university, class, and student details if required.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md`.
3. Open **Settings → Pages**.
4. Under Build and deployment, select **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to publish your site.

---
**Student:** Aman Kumar  
**University:** Ajeenkya D Y Patil University  
**URN / Roll No.:** E25BO32571

Created by **Aman Kumar**.
